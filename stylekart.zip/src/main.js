/**
 * StyleKart - Modern Online Shopping Engine
 * Vanilla JavaScript Frontend Architecture
 */

// ----------------------------------------------------
// Configuration & State
// ----------------------------------------------------
const API_URL_BASE = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');
const API_BASE = API_URL_BASE ? `${API_URL_BASE}/api` : '/api';

const state = {
  products: [],
  filteredProducts: [],
  activeCategory: 'All',
  searchQuery: '',
  maxPrice: 15000,
  inStockOnly: false,
  sortBy: 'featured',
  cart: JSON.parse(localStorage.getItem('stylekart_cart') || '[]'),
  appliedCoupon: JSON.parse(localStorage.getItem('stylekart_coupon') || 'null'),
  token: localStorage.getItem('stylekart_token') || null,
  user: JSON.parse(localStorage.getItem('stylekart_user') || 'null'),
  activeQuickViewProduct: null,
  databaseMode: 'Checking...'
};

// Format currency in Indian Rupees (INR ₹)
function formatINR(amount) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  }).format(amount || 0);
}

// ----------------------------------------------------
// Toast Notification Utility
// ----------------------------------------------------
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  const bgColors = {
    info: 'bg-stone-900 text-white',
    success: 'bg-emerald-900 text-white',
    error: 'bg-rose-900 text-white',
    warning: 'bg-amber-900 text-white'
  };

  toast.className = `toast-item px-4 py-2.5 rounded-lg text-xs font-medium shadow-xl flex items-center gap-2.5 animate-fade-in ${bgColors[type] || bgColors.info}`;
  
  let iconSvg = '<svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>';
  if (type === 'error') {
    iconSvg = '<svg class="w-4 h-4 text-rose-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>';
  }

  toast.innerHTML = `${iconSvg}<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    setTimeout(() => toast.remove(), 250);
  }, 3200);
}

// ----------------------------------------------------
// API Client
// ----------------------------------------------------
async function fetchAPI(endpoint, options = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(state.token ? { Authorization: `Bearer ${state.token}` } : {}),
    ...(options.headers || {})
  };

  try {
    const res = await fetch(`${API_BASE}${endpoint}`, {
      ...options,
      headers
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || `HTTP error ${res.status}`);
    }
    return data;
  } catch (err) {
    console.error(`API Error on [${endpoint}]:`, err);
    throw err;
  }
}

// ----------------------------------------------------
// Auth & Session Management
// ----------------------------------------------------
function updateAuthUI() {
  const authLabel = document.getElementById('auth-label');
  const dropdownUserName = document.getElementById('dropdown-user-name');
  const dropdownUserRole = document.getElementById('dropdown-user-role');
  const adminPortalBtn = document.getElementById('admin-portal-btn');
  const menuAdminBtn = document.getElementById('menu-admin-btn');

  if (state.user && state.token) {
    authLabel.textContent = state.user.name.split(' ')[0];
    dropdownUserName.textContent = state.user.name;
    dropdownUserRole.textContent = `${state.user.role} · ${state.user.email}`;

    if (state.user.role === 'admin') {
      adminPortalBtn.classList.remove('hidden');
      if (menuAdminBtn) menuAdminBtn.classList.remove('hidden');
    } else {
      if (menuAdminBtn) menuAdminBtn.classList.add('hidden');
    }
  } else {
    authLabel.textContent = 'Sign In';
    if (adminPortalBtn) adminPortalBtn.classList.add('hidden');
    if (menuAdminBtn) menuAdminBtn.classList.add('hidden');
  }
}

async function checkCurrentSession() {
  if (!state.token) {
    updateAuthUI();
    return;
  }

  try {
    const data = await fetchAPI('/auth/me');
    state.user = data.user;
    localStorage.setItem('stylekart_user', JSON.stringify(data.user));
    updateAuthUI();
  } catch (err) {
    console.warn('Session expired or invalid, logging out.');
    logout();
  }
}

function logout() {
  state.token = null;
  state.user = null;
  localStorage.removeItem('stylekart_token');
  localStorage.removeItem('stylekart_user');
  updateAuthUI();
  document.getElementById('user-dropdown')?.classList.add('hidden');
  showToast('You have signed out successfully.', 'info');
}

// ----------------------------------------------------
// System Health Check
// ----------------------------------------------------
async function checkSystemHealth() {
  try {
    const data = await fetchAPI('/health');
    state.databaseMode = data.databaseMode;
    const dbPill = document.getElementById('system-db-pill');
    const dbText = document.getElementById('system-db-text');
    const adminDbStatus = document.getElementById('admin-db-status');

    if (data.mongoConnected) {
      if (dbText) dbText.textContent = 'MongoDB Atlas Connected';
      if (dbPill) dbPill.className = 'hidden md:inline-flex items-center gap-1.5 text-emerald-400';
      if (adminDbStatus) adminDbStatus.textContent = 'MongoDB Atlas (Production Cluster)';
    } else {
      if (dbText) dbText.textContent = 'High-Speed Demo Mode (In-Memory)';
      if (dbPill) dbPill.className = 'hidden md:inline-flex items-center gap-1.5 text-stone-400';
      if (adminDbStatus) adminDbStatus.textContent = 'In-Memory Store (Zero Latency Demo)';
    }
  } catch (err) {
    console.warn('Backend health check skipped:', err.message);
  }
}

// ----------------------------------------------------
// Product Catalog Engine
// ----------------------------------------------------
async function loadProducts() {
  const grid = document.getElementById('product-grid');
  const resultsCount = document.getElementById('results-count-text');
  
  if (grid) {
    grid.innerHTML = Array(4).fill(0).map(() => `
      <div class="bg-white rounded-xl border border-stone-200 overflow-hidden animate-pulse">
        <div class="h-60 bg-stone-200"></div>
        <div class="p-4 space-y-2">
          <div class="h-3 bg-stone-200 rounded w-1/3"></div>
          <div class="h-4 bg-stone-200 rounded w-3/4"></div>
          <div class="h-4 bg-stone-200 rounded w-1/2"></div>
        </div>
      </div>
    `).join('');
  }

  try {
    const params = new URLSearchParams();
    if (state.activeCategory && state.activeCategory !== 'All') {
      params.append('category', state.activeCategory);
    }
    if (state.searchQuery) {
      params.append('search', state.searchQuery);
    }
    if (state.sortBy && state.sortBy !== 'featured') {
      params.append('sort', state.sortBy);
    }

    const data = await fetchAPI(`/products?${params.toString()}`);
    state.products = data.products || [];
    applyClientFilters();
  } catch (err) {
    showToast('Failed to load catalog products.', 'error');
    if (grid) {
      grid.innerHTML = `<div class="col-span-full py-12 text-center text-xs text-rose-600">Failed to load product items. Ensure backend is running.</div>`;
    }
  }
}

function applyClientFilters() {
  let list = [...state.products];

  // Price filter
  list = list.filter((p) => p.price <= state.maxPrice);

  // In-stock only filter
  if (state.inStockOnly) {
    list = list.filter((p) => p.stock > 0);
  }

  state.filteredProducts = list;
  renderProductGrid();

  const resultsCount = document.getElementById('results-count-text');
  if (resultsCount) {
    resultsCount.textContent = `Showing ${list.length} item${list.length === 1 ? '' : 's'}`;
  }
}

function renderProductGrid() {
  const grid = document.getElementById('product-grid');
  const emptyState = document.getElementById('empty-state');
  if (!grid) return;

  if (state.filteredProducts.length === 0) {
    grid.innerHTML = '';
    if (emptyState) emptyState.classList.remove('hidden');
    return;
  }

  if (emptyState) emptyState.classList.add('hidden');

  grid.innerHTML = state.filteredProducts.map((p) => {
    const discountPercent = p.originalPrice ? Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100) : 0;
    const isOutOfStock = p.stock <= 0;
    const isLowStock = p.stock > 0 && p.stock <= 15;

    return `
      <article class="product-card bg-white rounded-xl border border-stone-200 overflow-hidden flex flex-col group relative">
        <!-- Image Container -->
        <div class="relative h-64 bg-stone-100 overflow-hidden cursor-pointer" onclick="window.StyleKart.openQuickView('${p.id}')">
          <img
            src="${p.image}"
            alt="${p.name}"
            referrerpolicy="no-referrer"
            loading="lazy"
            class="w-full h-full object-cover object-center group-hover:scale-103 transition-transform duration-300"
            onerror="this.onerror=null; this.src='/src/assets/images/hero_shopping_banner_1792683257533.jpg';"
          />

          <!-- Quick View floating action -->
          <div class="absolute inset-0 bg-stone-950/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-4">
            <button
              type="button"
              onclick="event.stopPropagation(); window.StyleKart.openQuickView('${p.id}')"
              class="px-3.5 py-1.5 bg-white/95 text-stone-900 text-xs font-semibold rounded-md shadow-md hover:bg-white transition-colors"
            >
              Quick View
            </button>
          </div>

          ${discountPercent > 0 ? `
            <div class="absolute top-2.5 left-2.5 px-2 py-0.5 bg-stone-900 text-white text-[10px] font-bold rounded">
              ${discountPercent}% OFF
            </div>
          ` : ''}

          ${isOutOfStock ? `
            <div class="absolute top-2.5 right-2.5 px-2 py-0.5 bg-rose-900 text-white text-[10px] font-bold rounded">
              Out of Stock
            </div>
          ` : isLowStock ? `
            <div class="absolute top-2.5 right-2.5 px-2 py-0.5 bg-amber-800 text-white text-[10px] font-semibold rounded">
              Only ${p.stock} left
            </div>
          ` : ''}
        </div>

        <!-- Content -->
        <div class="p-5 flex-1 flex flex-col justify-between space-y-3">
          <div class="space-y-1.5">
            <!-- Zero-Pill Unboxed Metadata -->
            <div class="flex items-center gap-1.5 text-xs text-stone-500 font-medium">
              <span>${p.category}</span>
              <span aria-hidden="true">·</span>
              <span class="flex items-center text-amber-500">★ ${p.rating || '4.8'}</span>
              <span class="text-stone-400 text-[11px]">(${p.reviewsCount || 12})</span>
            </div>

            <h3 class="font-display text-sm font-semibold text-stone-900 line-clamp-1 group-hover:text-stone-950">
              <a href="javascript:void(0)" onclick="window.StyleKart.openQuickView('${p.id}')">${p.name}</a>
            </h3>

            <p class="text-xs text-stone-500 line-clamp-2 leading-relaxed">
              ${p.description || ''}
            </p>
          </div>

          <!-- Price & Add Button Row -->
          <div class="pt-2 border-t border-stone-100 flex items-center justify-between gap-3">
            <div class="flex flex-col">
              <span class="text-base font-bold text-stone-950 tabular-nums">${formatINR(p.price)}</span>
              ${p.originalPrice && p.originalPrice > p.price ? `
                <span class="text-[11px] text-stone-400 line-through tabular-nums -mt-1">${formatINR(p.originalPrice)}</span>
              ` : ''}
            </div>

            <button
              type="button"
              ${isOutOfStock ? 'disabled' : ''}
              onclick="window.StyleKart.addToCart('${p.id}')"
              class="px-3.5 py-1.5 ${isOutOfStock ? 'bg-stone-200 text-stone-400 cursor-not-allowed' : 'bg-stone-900 hover:bg-stone-800 text-white'} text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shadow-2xs"
            >
              ${isOutOfStock ? 'Sold Out' : 'Add to Bag'}
            </button>
          </div>
        </div>
      </article>
    `;
  }).join('');
}

// ----------------------------------------------------
// Shopping Cart Logic
// ----------------------------------------------------
function addToCart(productId, qty = 1) {
  const product = state.products.find((p) => p.id === productId);
  if (!product) {
    showToast('Product not found in catalog.', 'error');
    return;
  }

  if (product.stock <= 0) {
    showToast('Sorry, this product is currently sold out.', 'error');
    return;
  }

  const existing = state.cart.find((item) => item.id === productId);
  if (existing) {
    if (existing.quantity + qty > product.stock) {
      showToast(`Only ${product.stock} units available in stock.`, 'warning');
      return;
    }
    existing.quantity += qty;
  } else {
    state.cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      originalPrice: product.originalPrice,
      image: product.image,
      stock: product.stock,
      quantity: qty
    });
  }

  saveCart();
  renderCartDrawer();
  showToast(`Added "${product.name}" to your bag.`, 'success');

  // Open drawer automatically on mobile/desktop
  openCartDrawer();
}

function updateCartQuantity(productId, delta) {
  const item = state.cart.find((i) => i.id === productId);
  if (!item) return;

  const newQty = item.quantity + delta;
  if (newQty <= 0) {
    removeFromCart(productId);
    return;
  }

  if (newQty > item.stock) {
    showToast(`Maximum available stock reached (${item.stock}).`, 'warning');
    return;
  }

  item.quantity = newQty;
  saveCart();
  renderCartDrawer();
}

function removeFromCart(productId) {
  state.cart = state.cart.filter((i) => i.id !== productId);
  saveCart();
  renderCartDrawer();
  showToast('Item removed from shopping bag.', 'info');
}

function saveCart() {
  localStorage.setItem('stylekart_cart', JSON.stringify(state.cart));
  updateCartBadge();
}

function updateCartBadge() {
  const badge = document.getElementById('cart-count-badge');
  const drawerCount = document.getElementById('drawer-cart-count');
  const count = state.cart.reduce((sum, item) => sum + item.quantity, 0);

  if (badge) badge.textContent = count;
  if (drawerCount) drawerCount.textContent = `(${count} item${count === 1 ? '' : 's'})`;
}

function calculateCartTotals() {
  const subtotal = state.cart.reduce((sum, i) => sum + i.price * i.quantity, 0);
  let discount = 0;

  if (state.appliedCoupon && state.appliedCoupon.code === 'STYLE10') {
    discount = Math.round(subtotal * 0.1);
  }

  const shipping = subtotal >= 999 || subtotal === 0 ? 0 : 99;
  const total = Math.max(0, subtotal - discount + shipping);

  return { subtotal, discount, shipping, total };
}

function renderCartDrawer() {
  const itemsContainer = document.getElementById('cart-items-container');
  const emptyMsg = document.getElementById('cart-empty-message');
  const footer = document.getElementById('cart-footer');
  const subtotalEl = document.getElementById('cart-subtotal');
  const discountRow = document.getElementById('cart-discount-row');
  const discountEl = document.getElementById('cart-discount');
  const shippingEl = document.getElementById('cart-shipping');
  const totalEl = document.getElementById('cart-total');

  if (!itemsContainer) return;

  if (state.cart.length === 0) {
    itemsContainer.innerHTML = '';
    emptyMsg?.classList.remove('hidden');
    footer?.classList.add('hidden');
    return;
  }

  emptyMsg?.classList.add('hidden');
  footer?.classList.remove('hidden');

  itemsContainer.innerHTML = state.cart.map((item) => `
    <div class="flex gap-3 p-3 bg-stone-50 rounded-xl border border-stone-200">
      <img
        src="${item.image}"
        alt="${item.name}"
        class="w-18 h-18 object-cover rounded-lg bg-stone-200 shrink-0"
        onerror="this.src='/src/assets/images/hero_shopping_banner_1792683257533.jpg';"
      />
      <div class="flex-1 flex flex-col justify-between">
        <div>
          <div class="flex items-start justify-between gap-2">
            <h4 class="text-xs font-bold text-stone-900 leading-snug line-clamp-2">${item.name}</h4>
            <button
              type="button"
              onclick="window.StyleKart.removeFromCart('${item.id}')"
              class="text-stone-400 hover:text-rose-600 transition-colors p-1 -mr-1"
              title="Remove item"
            >
              <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
            </button>
          </div>
          <div class="text-xs font-semibold text-stone-900 mt-1 tabular-nums">${formatINR(item.price)}</div>
        </div>

        <div class="flex items-center justify-between pt-2">
          <div class="flex items-center border border-stone-300 rounded-md bg-white">
            <button
              type="button"
              onclick="window.StyleKart.updateCartQuantity('${item.id}', -1)"
              class="px-2 py-0.5 text-xs text-stone-600 hover:text-stone-900 font-bold"
            >
              -
            </button>
            <span class="px-2 py-0.5 text-xs font-bold text-stone-900 tabular-nums">${item.quantity}</span>
            <button
              type="button"
              onclick="window.StyleKart.updateCartQuantity('${item.id}', 1)"
              class="px-2 py-0.5 text-xs text-stone-600 hover:text-stone-900 font-bold"
            >
              +
            </button>
          </div>
          <span class="text-xs font-bold text-stone-950 tabular-nums">${formatINR(item.price * item.quantity)}</span>
        </div>
      </div>
    </div>
  `).join('');

  const totals = calculateCartTotals();
  if (subtotalEl) subtotalEl.textContent = formatINR(totals.subtotal);
  if (shippingEl) shippingEl.textContent = totals.shipping === 0 ? 'Free' : formatINR(totals.shipping);
  if (totalEl) totalEl.textContent = formatINR(totals.total);

  if (totals.discount > 0) {
    discountRow?.classList.remove('hidden');
    if (discountEl) discountEl.textContent = `-${formatINR(totals.discount)}`;
  } else {
    discountRow?.classList.add('hidden');
  }
}

function openCartDrawer() {
  renderCartDrawer();
  document.getElementById('cart-drawer-overlay')?.classList.remove('hidden');
}

function closeCartDrawer() {
  document.getElementById('cart-drawer-overlay')?.classList.add('hidden');
}

function applyCouponCode() {
  const input = document.getElementById('coupon-input');
  const feedback = document.getElementById('coupon-feedback');
  const code = input?.value.trim().toUpperCase();

  if (!code) {
    showToast('Please enter a coupon code.', 'warning');
    return;
  }

  if (code === 'STYLE10') {
    state.appliedCoupon = { code: 'STYLE10', discountPercent: 10 };
    localStorage.setItem('stylekart_coupon', JSON.stringify(state.appliedCoupon));
    if (feedback) {
      feedback.textContent = 'Coupon STYLE10 applied: 10% discount added!';
      feedback.className = 'text-[11px] text-emerald-600 font-medium';
      feedback.classList.remove('hidden');
    }
    renderCartDrawer();
    showToast('Coupon STYLE10 applied: 10% discount!', 'success');
  } else {
    if (feedback) {
      feedback.textContent = 'Invalid promo code. Try "STYLE10".';
      feedback.className = 'text-[11px] text-rose-600 font-medium';
      feedback.classList.remove('hidden');
    }
    showToast('Invalid promo code. Use code STYLE10.', 'error');
  }
}

// ----------------------------------------------------
// Quick View Modal
// ----------------------------------------------------
function openQuickView(productId) {
  const product = state.products.find((p) => p.id === productId);
  if (!product) return;

  state.activeQuickViewProduct = product;

  document.getElementById('qv-image').src = product.image;
  document.getElementById('qv-title').textContent = product.name;
  document.getElementById('qv-category').textContent = product.category;
  document.getElementById('qv-price').textContent = formatINR(product.price);
  
  const origPriceEl = document.getElementById('qv-original-price');
  if (product.originalPrice && product.originalPrice > product.price) {
    origPriceEl.textContent = formatINR(product.originalPrice);
    origPriceEl.classList.remove('hidden');
  } else {
    origPriceEl.classList.add('hidden');
  }

  document.getElementById('qv-stock').textContent = product.stock > 0 ? `In Stock (${product.stock} units)` : 'Sold Out';
  document.getElementById('qv-stock').className = product.stock > 0 ? 'text-emerald-700 font-medium' : 'text-rose-600 font-medium';
  document.getElementById('qv-reviews').textContent = `(${product.reviewsCount || 10} verified reviews)`;
  document.getElementById('qv-desc').textContent = product.description;

  document.getElementById('quickview-modal')?.classList.remove('hidden');
}

function closeQuickView() {
  document.getElementById('quickview-modal')?.classList.add('hidden');
  state.activeQuickViewProduct = null;
}

// ----------------------------------------------------
// Checkout & Order Confirmation
// ----------------------------------------------------
function openCheckoutModal() {
  if (state.cart.length === 0) {
    showToast('Your shopping bag is empty.', 'warning');
    return;
  }

  // Pre-fill with authenticated user details if logged in
  if (!state.token) {
    showToast('Please sign in or continue as guest to complete checkout.', 'info');
    openAuthModal('login');
    return;
  }

  const nameInput = document.getElementById('ship-name');
  if (nameInput && state.user) {
    nameInput.value = state.user.name || '';
  }

  const totals = calculateCartTotals();
  document.getElementById('checkout-subtotal').textContent = formatINR(totals.subtotal);
  document.getElementById('checkout-shipping').textContent = totals.shipping === 0 ? 'Free' : formatINR(totals.shipping);
  document.getElementById('checkout-total').textContent = formatINR(totals.total);

  const discountRow = document.getElementById('checkout-discount-row');
  const discountEl = document.getElementById('checkout-discount');
  if (totals.discount > 0) {
    discountRow?.classList.remove('hidden');
    if (discountEl) discountEl.textContent = `-${formatINR(totals.discount)}`;
  } else {
    discountRow?.classList.add('hidden');
  }

  closeCartDrawer();
  document.getElementById('checkout-modal')?.classList.remove('hidden');
}

function closeCheckoutModal() {
  document.getElementById('checkout-modal')?.classList.add('hidden');
}

async function handlePlaceOrder(e) {
  e.preventDefault();
  const submitBtn = document.getElementById('place-order-submit-btn');

  const name = document.getElementById('ship-name').value.trim();
  const phone = document.getElementById('ship-phone').value.trim();
  const address = document.getElementById('ship-address').value.trim();
  const city = document.getElementById('ship-city').value.trim();
  const stateVal = document.getElementById('ship-state').value.trim();
  const pincode = document.getElementById('ship-pincode').value.trim();

  const paymentMethodInput = document.querySelector('input[name="payment-method"]:checked');
  const paymentMethod = paymentMethodInput ? paymentMethodInput.value : 'Simulated UPI';

  const totals = calculateCartTotals();

  const orderPayload = {
    items: state.cart.map((i) => ({
      id: i.id,
      name: i.name,
      price: i.price,
      quantity: i.quantity
    })),
    shippingAddress: {
      address,
      city,
      state: stateVal,
      pincode
    },
    customerName: name,
    customerPhone: phone,
    paymentMethod,
    discount: totals.discount
  };

  try {
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.innerHTML = '<span>Processing Order...</span>';
    }

    const data = await fetchAPI('/orders', {
      method: 'POST',
      body: JSON.stringify(orderPayload)
    });

    // Clear cart and coupon
    state.cart = [];
    state.appliedCoupon = null;
    saveCart();
    localStorage.removeItem('stylekart_coupon');

    // Close checkout and show confirmation
    closeCheckoutModal();
    openConfirmationModal(data.order);
    showToast('Your order was placed successfully!', 'success');

    // Reload products to reflect updated inventory
    loadProducts();
  } catch (err) {
    showToast(err.message || 'Checkout failed. Please check details.', 'error');
  } finally {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.innerHTML = '<span>Confirm & Place Order</span>';
    }
  }
}

function openConfirmationModal(order) {
  document.getElementById('confirm-order-id').textContent = order.id;
  document.getElementById('confirm-payment-method').textContent = `${order.paymentMethod} (Simulated)`;
  document.getElementById('confirm-total-amount').textContent = formatINR(order.total);
  document.getElementById('order-confirm-modal')?.classList.remove('hidden');
}

function closeConfirmationModal() {
  document.getElementById('order-confirm-modal')?.classList.add('hidden');
}

// ----------------------------------------------------
// Customer Orders History
// ----------------------------------------------------
async function openOrdersModal() {
  if (!state.token) {
    showToast('Please sign in to view your order history.', 'info');
    openAuthModal('login');
    return;
  }

  const modal = document.getElementById('orders-modal');
  const container = document.getElementById('orders-list-container');
  modal?.classList.remove('hidden');

  if (container) {
    container.innerHTML = `<div class="py-8 text-center text-xs text-stone-500">Retrieving your orders...</div>`;
  }

  try {
    const data = await fetchAPI('/orders/my-orders');
    const orders = data.orders || [];

    if (orders.length === 0) {
      container.innerHTML = `
        <div class="py-12 text-center space-y-2">
          <p class="font-display font-semibold text-stone-800">No Orders Yet</p>
          <p class="text-xs text-stone-500">Items you purchase will appear here with live simulated delivery tracking.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = orders.map((order) => {
      const statusColors = {
        Processing: 'bg-amber-100 text-amber-900',
        Shipped: 'bg-blue-100 text-blue-900',
        Delivered: 'bg-emerald-100 text-emerald-900',
        Cancelled: 'bg-rose-100 text-rose-900'
      };

      const dateStr = new Date(order.createdAt).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      });

      return `
        <div class="p-4 bg-stone-50 rounded-xl border border-stone-200 space-y-3">
          <div class="flex flex-wrap items-center justify-between gap-2 border-b border-stone-200 pb-2">
            <div>
              <span class="font-mono font-bold text-xs text-stone-900">${order.id}</span>
              <span class="text-xs text-stone-400 ml-2">${dateStr}</span>
            </div>
            <span class="px-2 py-0.5 rounded text-[11px] font-semibold ${statusColors[order.status] || 'bg-stone-200 text-stone-800'}">
              ${order.status}
            </span>
          </div>

          <div class="space-y-1.5 text-xs text-stone-700">
            ${order.items.map((item) => `
              <div class="flex justify-between items-center">
                <span>${item.quantity}x ${item.name}</span>
                <span class="font-medium tabular-nums">${formatINR(item.price * item.quantity)}</span>
              </div>
            `).join('')}
          </div>

          <div class="pt-2 border-t border-stone-200 flex justify-between items-center text-xs">
            <span class="text-stone-500">${order.paymentMethod}</span>
            <div class="font-bold text-stone-950 tabular-nums">Total: ${formatINR(order.total)}</div>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    if (container) {
      container.innerHTML = `<div class="py-8 text-center text-xs text-rose-600">Failed to load order history: ${err.message}</div>`;
    }
  }
}

function closeOrdersModal() {
  document.getElementById('orders-modal')?.classList.add('hidden');
}

// ----------------------------------------------------
// Admin Management Portal
// ----------------------------------------------------
function openAdminModal() {
  if (!state.token || state.user?.role !== 'admin') {
    showToast('Admin credentials required. Sign in as admin@stylekart.com', 'warning');
    openAuthModal('login');
    // Pre-fill admin
    fillDemoCredentials('admin');
    return;
  }

  document.getElementById('admin-modal')?.classList.remove('hidden');
  loadAdminStats();
  loadAdminOrders();
  loadAdminProducts();
}

function closeAdminModal() {
  document.getElementById('admin-modal')?.classList.add('hidden');
}

async function loadAdminStats() {
  try {
    const data = await fetchAPI('/admin/stats');
    document.getElementById('stat-revenue').textContent = formatINR(data.totalSales);
    document.getElementById('stat-orders').textContent = data.totalOrders;
    document.getElementById('stat-aov').textContent = formatINR(data.avgOrderValue);
    document.getElementById('stat-pending').textContent = data.pendingOrders;
    document.getElementById('admin-db-status').textContent = data.databaseMode;
  } catch (err) {
    console.error('Failed to load admin stats:', err);
  }
}

async function loadAdminOrders() {
  const tbody = document.getElementById('admin-orders-table-body');
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="6" class="p-4 text-center text-xs text-stone-500">Loading orders...</td></tr>`;

  try {
    const data = await fetchAPI('/admin/orders');
    const orders = data.orders || [];

    if (orders.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" class="p-4 text-center text-xs text-stone-500">No customer orders recorded yet.</td></tr>`;
      return;
    }

    tbody.innerHTML = orders.map((o) => `
      <tr class="hover:bg-stone-50 transition-colors">
        <td class="p-3 font-mono font-bold text-stone-900">${o.id}</td>
        <td class="p-3">
          <div class="font-medium text-stone-900">${o.customerName}</div>
          <div class="text-[11px] text-stone-400">${o.customerEmail}</div>
        </td>
        <td class="p-3">${o.items.length} items</td>
        <td class="p-3 font-semibold text-stone-900 tabular-nums">${formatINR(o.total)}</td>
        <td class="p-3">
          <span class="px-2 py-0.5 rounded text-[11px] font-semibold bg-stone-100 text-stone-800">${o.status}</span>
        </td>
        <td class="p-3">
          <select
            onchange="window.StyleKart.updateOrderStatus('${o.id}', this.value)"
            class="text-xs border border-stone-200 rounded px-2 py-1 bg-white cursor-pointer"
          >
            <option value="Pending" ${o.status === 'Pending' ? 'selected' : ''}>Pending</option>
            <option value="Processing" ${o.status === 'Processing' ? 'selected' : ''}>Processing</option>
            <option value="Shipped" ${o.status === 'Shipped' ? 'selected' : ''}>Shipped</option>
            <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
            <option value="Cancelled" ${o.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
          </select>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="6" class="p-4 text-center text-xs text-rose-600">Failed to load admin orders.</td></tr>`;
  }
}

async function updateOrderStatus(orderId, newStatus) {
  try {
    await fetchAPI(`/admin/orders/${orderId}/status`, {
      method: 'PUT',
      body: JSON.stringify({ status: newStatus })
    });
    showToast(`Order ${orderId} status set to ${newStatus}`, 'success');
    loadAdminStats();
    loadAdminOrders();
  } catch (err) {
    showToast('Failed to update status', 'error');
  }
}

async function loadAdminProducts() {
  const tbody = document.getElementById('admin-products-table-body');
  if (!tbody) return;

  tbody.innerHTML = `<tr><td colspan="5" class="p-4 text-center text-xs text-stone-500">Loading catalog...</td></tr>`;

  try {
    const data = await fetchAPI('/products');
    const products = data.products || [];

    tbody.innerHTML = products.map((p) => `
      <tr class="hover:bg-stone-50 transition-colors">
        <td class="p-3">
          <div class="flex items-center gap-2">
            <img src="${p.image}" class="w-8 h-8 rounded object-cover bg-stone-200" onerror="this.src='/src/assets/images/hero_shopping_banner_1792683257533.jpg';" />
            <span class="font-medium text-stone-900">${p.name}</span>
          </div>
        </td>
        <td class="p-3 text-stone-600">${p.category}</td>
        <td class="p-3 font-semibold text-stone-900 tabular-nums">${formatINR(p.price)}</td>
        <td class="p-3">
          <span class="tabular-nums font-medium ${p.stock <= 15 ? 'text-amber-700' : 'text-stone-900'}">${p.stock} units</span>
        </td>
        <td class="p-3 text-right">
          <button
            type="button"
            onclick="window.StyleKart.deleteProduct('${p.id}')"
            class="px-2 py-1 text-xs text-rose-600 hover:bg-rose-50 rounded transition-colors"
          >
            Delete
          </button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="5" class="p-4 text-center text-xs text-rose-600">Failed to load admin products.</td></tr>`;
  }
}

async function handleAddProduct(e) {
  e.preventDefault();
  const name = document.getElementById('new-prod-name').value.trim();
  const category = document.getElementById('new-prod-category').value;
  const price = parseFloat(document.getElementById('new-prod-price').value);
  const stock = parseInt(document.getElementById('new-prod-stock').value, 10);
  const description = document.getElementById('new-prod-desc').value.trim();

  try {
    await fetchAPI('/products', {
      method: 'POST',
      body: JSON.stringify({ name, category, price, stock, description })
    });

    showToast(`Product "${name}" added to inventory!`, 'success');
    document.getElementById('add-product-form').reset();
    loadAdminProducts();
    loadProducts();
  } catch (err) {
    showToast(err.message || 'Failed to add product.', 'error');
  }
}

async function deleteProduct(productId) {
  try {
    await fetchAPI(`/products/${productId}`, { method: 'DELETE' });
    showToast('Product deleted from inventory.', 'info');
    loadAdminProducts();
    loadProducts();
  } catch (err) {
    showToast('Failed to delete product', 'error');
  }
}

// ----------------------------------------------------
// Authentication Modal Logic
// ----------------------------------------------------
let authMode = 'login'; // 'login' or 'register'

function openAuthModal(mode = 'login') {
  authMode = mode;
  const title = document.getElementById('auth-modal-title');
  const subtitle = document.getElementById('auth-modal-subtitle');
  const tabLogin = document.getElementById('tab-login');
  const tabReg = document.getElementById('tab-register');
  const nameField = document.getElementById('register-name-field');
  const submitBtn = document.getElementById('auth-submit-btn');
  const errBox = document.getElementById('auth-error-msg');

  if (errBox) errBox.classList.add('hidden');

  if (authMode === 'login') {
    if (title) title.textContent = 'Sign In to StyleKart';
    if (subtitle) subtitle.textContent = 'Access your cart, order records, and member perks.';
    tabLogin?.classList.add('bg-white', 'text-stone-900', 'shadow-xs');
    tabLogin?.classList.remove('text-stone-600');
    tabReg?.classList.remove('bg-white', 'text-stone-900', 'shadow-xs');
    tabReg?.classList.add('text-stone-600');
    nameField?.classList.add('hidden');
    if (submitBtn) submitBtn.innerHTML = '<span>Sign In</span>';
  } else {
    if (title) title.textContent = 'Create StyleKart Account';
    if (subtitle) subtitle.textContent = 'Join to experience seamless curated shopping.';
    tabReg?.classList.add('bg-white', 'text-stone-900', 'shadow-xs');
    tabReg?.classList.remove('text-stone-600');
    tabLogin?.classList.remove('bg-white', 'text-stone-900', 'shadow-xs');
    tabLogin?.classList.add('text-stone-600');
    nameField?.classList.remove('hidden');
    if (submitBtn) submitBtn.innerHTML = '<span>Register Account</span>';
  }

  document.getElementById('auth-modal')?.classList.remove('hidden');
}

function closeAuthModal() {
  document.getElementById('auth-modal')?.classList.add('hidden');
}

function fillDemoCredentials(type = 'customer') {
  const emailInput = document.getElementById('auth-email');
  const passInput = document.getElementById('auth-password');
  const nameInput = document.getElementById('auth-name');

  if (type === 'admin') {
    if (emailInput) emailInput.value = 'admin@stylekart.com';
    if (passInput) passInput.value = 'admin123';
  } else {
    if (emailInput) emailInput.value = 'user@stylekart.com';
    if (passInput) passInput.value = 'user123';
    if (nameInput) nameInput.value = 'Aarav Sharma';
  }
}

async function handleAuthSubmit(e) {
  e.preventDefault();
  const errBox = document.getElementById('auth-error-msg');
  const email = document.getElementById('auth-email').value.trim();
  const password = document.getElementById('auth-password').value;
  const name = document.getElementById('auth-name').value.trim();

  if (errBox) errBox.classList.add('hidden');

  try {
    const endpoint = authMode === 'login' ? '/auth/login' : '/auth/register';
    const payload = authMode === 'login' ? { email, password } : { name, email, password };

    const data = await fetchAPI(endpoint, {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    state.token = data.token;
    state.user = data.user;
    localStorage.setItem('stylekart_token', data.token);
    localStorage.setItem('stylekart_user', JSON.stringify(data.user));

    updateAuthUI();
    closeAuthModal();
    showToast(data.message || 'Signed in successfully!', 'success');

    // If admin logged in, open admin portal automatically
    if (data.user?.role === 'admin') {
      openAdminModal();
    }
  } catch (err) {
    if (errBox) {
      errBox.textContent = err.message || 'Authentication failed. Please verify credentials.';
      errBox.classList.remove('hidden');
    }
  }
}

// ----------------------------------------------------
// Event Listeners & Initialization
// ----------------------------------------------------
function setupEventListeners() {
  // Navigation categories
  document.querySelectorAll('.nav-cat-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const cat = btn.getAttribute('data-cat') || 'All';
      setCategory(cat);
    });
  });

  // Filter tabs
  document.querySelectorAll('#category-tabs .cat-pill').forEach((btn) => {
    btn.addEventListener('click', () => {
      const cat = btn.getAttribute('data-cat') || 'All';
      setCategory(cat);
    });
  });

  // Hero campaign CTA
  document.getElementById('hero-filter-fashion')?.addEventListener('click', () => {
    setCategory('Fashion');
    document.getElementById('catalog-section')?.scrollIntoView({ behavior: 'smooth' });
  });

  // Search Inputs (Desktop & Mobile)
  const debounce = (fn, delay = 250) => {
    let t;
    return (...args) => {
      clearTimeout(t);
      t = setTimeout(() => fn(...args), delay);
    };
  };

  const handleSearch = (val) => {
    state.searchQuery = val.trim();
    loadProducts();
  };

  const debouncedSearch = debounce(handleSearch, 300);

  document.getElementById('global-search-input')?.addEventListener('input', (e) => {
    debouncedSearch(e.target.value);
  });
  document.getElementById('mobile-search-input')?.addEventListener('input', (e) => {
    debouncedSearch(e.target.value);
  });

  // Sort dropdown
  document.getElementById('sort-select')?.addEventListener('change', (e) => {
    state.sortBy = e.target.value;
    loadProducts();
  });

  // Filter Drawer Toggle
  document.getElementById('filter-drawer-toggle')?.addEventListener('click', () => {
    document.getElementById('filter-panel')?.classList.toggle('hidden');
  });

  // Price Slider
  const priceSlider = document.getElementById('price-slider');
  const maxPriceLabel = document.getElementById('max-price-label');
  priceSlider?.addEventListener('input', (e) => {
    const val = parseInt(e.target.value, 10);
    state.maxPrice = val;
    if (maxPriceLabel) maxPriceLabel.textContent = formatINR(val);
    applyClientFilters();
  });

  // In stock checkbox
  document.getElementById('in-stock-only')?.addEventListener('change', (e) => {
    state.inStockOnly = e.target.checked;
    applyClientFilters();
  });

  // Reset filters
  const resetFilters = () => {
    state.maxPrice = 15000;
    state.inStockOnly = false;
    state.searchQuery = '';
    state.sortBy = 'featured';
    if (priceSlider) priceSlider.value = 15000;
    if (maxPriceLabel) maxPriceLabel.textContent = formatINR(15000);
    const stockBox = document.getElementById('in-stock-only');
    if (stockBox) stockBox.checked = false;
    const globalSearch = document.getElementById('global-search-input');
    if (globalSearch) globalSearch.value = '';
    const mobileSearch = document.getElementById('mobile-search-input');
    if (mobileSearch) mobileSearch.value = '';
    const sortSelect = document.getElementById('sort-select');
    if (sortSelect) sortSelect.value = 'featured';
    setCategory('All');
  };

  document.getElementById('reset-filters-btn')?.addEventListener('click', resetFilters);
  document.getElementById('empty-reset-btn')?.addEventListener('click', resetFilters);

  // Cart Drawer triggers
  document.getElementById('cart-trigger-btn')?.addEventListener('click', openCartDrawer);
  document.getElementById('close-cart-btn')?.addEventListener('click', closeCartDrawer);
  document.getElementById('continue-shopping-btn')?.addEventListener('click', closeCartDrawer);
  document.getElementById('apply-coupon-btn')?.addEventListener('click', applyCouponCode);
  document.getElementById('proceed-checkout-btn')?.addEventListener('click', openCheckoutModal);

  // Quick View triggers
  document.getElementById('close-quickview-btn')?.addEventListener('click', closeQuickView);
  document.getElementById('qv-add-cart-btn')?.addEventListener('click', () => {
    if (state.activeQuickViewProduct) {
      addToCart(state.activeQuickViewProduct.id, 1);
      closeQuickView();
    }
  });

  // Checkout modal
  document.getElementById('close-checkout-btn')?.addEventListener('click', closeCheckoutModal);
  document.getElementById('checkout-form')?.addEventListener('submit', handlePlaceOrder);

  // Confirmation modal
  document.getElementById('confirm-done-btn')?.addEventListener('click', closeConfirmationModal);
  document.getElementById('view-order-history-btn')?.addEventListener('click', () => {
    closeConfirmationModal();
    openOrdersModal();
  });

  // Orders modal
  document.getElementById('close-orders-btn')?.addEventListener('click', closeOrdersModal);

  // Auth modal triggers
  document.getElementById('auth-btn')?.addEventListener('click', () => {
    if (state.token) {
      document.getElementById('user-dropdown')?.classList.toggle('hidden');
    } else {
      openAuthModal('login');
    }
  });

  document.getElementById('close-auth-btn')?.addEventListener('click', closeAuthModal);
  document.getElementById('tab-login')?.addEventListener('click', () => openAuthModal('login'));
  document.getElementById('tab-register')?.addEventListener('click', () => openAuthModal('register'));
  document.getElementById('quick-cust-btn')?.addEventListener('click', () => fillDemoCredentials('customer'));
  document.getElementById('quick-admin-btn')?.addEventListener('click', () => fillDemoCredentials('admin'));
  document.getElementById('auth-form')?.addEventListener('submit', handleAuthSubmit);

  // Dropdown menu items
  document.getElementById('menu-orders-btn')?.addEventListener('click', () => {
    document.getElementById('user-dropdown')?.classList.add('hidden');
    openOrdersModal();
  });
  document.getElementById('menu-admin-btn')?.addEventListener('click', () => {
    document.getElementById('user-dropdown')?.classList.add('hidden');
    openAdminModal();
  });
  document.getElementById('logout-btn')?.addEventListener('click', logout);

  // Admin Portal Triggers
  document.getElementById('admin-portal-btn')?.addEventListener('click', openAdminModal);
  document.getElementById('footer-admin-trigger')?.addEventListener('click', openAdminModal);
  document.getElementById('close-admin-btn')?.addEventListener('click', closeAdminModal);
  document.getElementById('refresh-admin-orders-btn')?.addEventListener('click', loadAdminOrders);
  document.getElementById('add-product-form')?.addEventListener('submit', handleAddProduct);

  // Admin Tab Switchers
  const adminTabOverview = document.getElementById('admin-tab-overview');
  const adminTabOrders = document.getElementById('admin-tab-orders');
  const adminTabProducts = document.getElementById('admin-tab-products');

  const adminViewOverview = document.getElementById('admin-view-overview');
  const adminViewOrders = document.getElementById('admin-view-orders');
  const adminViewProducts = document.getElementById('admin-view-products');

  const setAdminTab = (tab) => {
    [adminTabOverview, adminTabOrders, adminTabProducts].forEach((t) => {
      t?.classList.remove('font-bold', 'text-stone-900', 'border-b-2', 'border-stone-900');
      t?.classList.add('font-medium', 'text-stone-500');
    });

    [adminViewOverview, adminViewOrders, adminViewProducts].forEach((v) => v?.classList.add('hidden'));

    if (tab === 'overview') {
      adminTabOverview?.classList.add('font-bold', 'text-stone-900', 'border-b-2', 'border-stone-900');
      adminViewOverview?.classList.remove('hidden');
      loadAdminStats();
    } else if (tab === 'orders') {
      adminTabOrders?.classList.add('font-bold', 'text-stone-900', 'border-b-2', 'border-stone-900');
      adminViewOrders?.classList.remove('hidden');
      loadAdminOrders();
    } else if (tab === 'products') {
      adminTabProducts?.classList.add('font-bold', 'text-stone-900', 'border-b-2', 'border-stone-900');
      adminViewProducts?.classList.remove('hidden');
      loadAdminProducts();
    }
  };

  adminTabOverview?.addEventListener('click', () => setAdminTab('overview'));
  adminTabOrders?.addEventListener('click', () => setAdminTab('orders'));
  adminTabProducts?.addEventListener('click', () => setAdminTab('products'));

  // Close dropdown on outside click
  window.addEventListener('click', (e) => {
    if (!e.target.closest('#auth-btn') && !e.target.closest('#user-dropdown')) {
      document.getElementById('user-dropdown')?.classList.add('hidden');
    }
  });
}

function setCategory(cat) {
  state.activeCategory = cat;

  // Update tabs visual state
  document.querySelectorAll('#category-tabs .cat-pill').forEach((btn) => {
    const btnCat = btn.getAttribute('data-cat');
    if (btnCat === cat) {
      btn.className = 'cat-pill active px-3 py-1.5 text-xs font-semibold rounded-md bg-white text-stone-950 shadow-xs whitespace-nowrap transition-colors';
    } else {
      btn.className = 'cat-pill px-3 py-1.5 text-xs font-medium rounded-md text-stone-600 hover:text-stone-950 whitespace-nowrap transition-colors';
    }
  });

  loadProducts();
}

// Global namespace for inline handlers
window.StyleKart = {
  addToCart,
  updateCartQuantity,
  removeFromCart,
  openQuickView,
  updateOrderStatus,
  deleteProduct
};

// ----------------------------------------------------
// Initialize
// ----------------------------------------------------
async function init() {
  updateCartBadge();
  setupEventListeners();
  await checkCurrentSession();
  await checkSystemHealth();
  await loadProducts();
}

// Start application when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
