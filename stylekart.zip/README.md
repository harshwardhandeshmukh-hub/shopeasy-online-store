# StyleKart - Modern Full-Stack E-Commerce Platform

A production-grade, responsive online shopping platform built with HTML5, CSS3, Vanilla JavaScript, Vite, Node.js, Express, MongoDB Atlas with Mongoose, bcryptjs, and JSON Web Tokens (JWT).

---

## 🌟 Key Features

1. **Responsive Storefront**: High-impact editorial hero banner, quick category navigation, real-time live search, and clean zero-pill aesthetics.
2. **Product Catalog**:
   - Detailed cards with studio imagery, Indian Rupee (`₹` INR) pricing, discounted badges, star ratings, and review counts.
   - Real-time search query filtering, category tabs (`Fashion`, `Electronics`, `Accessories`, `Home`), budget slider (₹500 - ₹15,000), and in-stock filter.
   - Dynamic sorting (Featured, Price: Low to High, Price: High to Low, Rating, Name).
   - Interactive Quick View modal.
3. **Shopping Bag & Cart**:
   - Slide-over drawer with itemized list, quantity steppers, and stock enforcement.
   - Promo coupon code system (`STYLE10` for 10% instant discount).
   - Free shipping calculation (Free above ₹999; ₹99 otherwise).
   - Real-time tabular-nums subtotal and total calculations with `localStorage` persistence.
4. **Authentication & Accounts**:
   - Registration and Login with client and server-side validation.
   - Password hashing with `bcryptjs` and stateless session management with JWT bearer tokens.
   - Pre-configured demo accounts for instant evaluation:
     - **Customer**: `user@stylekart.com` / `user123`
     - **Admin**: `admin@stylekart.com` / `admin123`
5. **Checkout & Simulated Payments**:
   - Delivery address collection (Full Name, Phone, Street, City, State, PIN code).
   - Simulated payment gateways: UPI Instant Pay, Cash on Delivery (COD), and Credit/Debit Card.
   - Clear simulated environment disclaimers (zero real transactions).
6. **Customer Order Tracking**:
   - Instant order confirmation modal with generated Order ID (`ORD-XXXXXX`).
   - Customer Order History modal with item summaries, timestamps, and live status (`Processing`, `Shipped`, `Delivered`).
7. **Admin Control Center**:
   - Role-protected admin dashboard.
   - Real-time business metrics: Total Sales (₹), Total Orders, Average Order Value (AOV), Pending Shipments.
   - Live Order Management: Update customer order status from dropdown.
   - Inventory Management: Add new products with image, category, price, and stock count, or delete existing items.
8. **Hybrid Storage Engine**:
   - MongoDB Atlas connection with Mongoose schemas and automatic database seeding.
   - High-performance In-Memory Demo Mode when `MONGODB_URI` is omitted or disconnected. Both modes support identical REST APIs.

---

## 🛠️ Technology Stack

| Layer | Technology |
|---|---|
| **Frontend** | HTML5, CSS3, Tailwind CSS, Vanilla JavaScript (ES2022), Vite |
| **Backend** | Node.js, Express.js |
| **Database** | MongoDB Atlas, Mongoose ODM (with automatic in-memory fallback) |
| **Authentication** | JSON Web Tokens (`jsonwebtoken`), `bcryptjs` |
| **Styling** | Modern CSS3, Google Fonts (`Outfit` & `Plus Jakarta Sans`) |

---

## 📂 Project Structure

```
stylekart/
├── .env.example            # Environment variables template
├── .gitignore              # Standard git ignores
├── index.html              # Clean semantic HTML5 single-page application
├── metadata.json           # Application metadata & permissions
├── package.json            # Scripts and npm dependencies
├── README.md               # Documentation and execution guide
├── server/
│   └── index.js            # Express REST API, Mongoose models, and In-Memory Demo store
├── server.ts               # Unified dev server with Vite middlewares (Port 3000)
├── src/
│   ├── assets/
│   │   └── images/         # High-resolution generated product photography
│   ├── main.js             # Client-side state, API client, cart, checkout & admin logic
│   └── style.css           # Custom CSS variables, typography, animations, and modal styles
├── tsconfig.json           # TypeScript configuration
├── vite.config.js          # Vite configuration with proxy to port 5000
└── vite.config.ts          # Vite configuration for TypeScript
```

---

## 🚀 Getting Started

### 1. Installation

Clone or extract the repository and install dependencies:

```bash
npm install
```

### 2. Environment Configuration

Copy the `.env.example` file to create `.env`:

```bash
cp .env.example .env
```

Default values in `.env`:
```env
PORT=5000
MONGODB_URI=
JWT_SECRET=stylekart_jwt_secret_dev_key_2026
VITE_API_URL=http://localhost:5000
```
*Note: If `MONGODB_URI` is left blank, StyleKart automatically runs in high-performance **In-Memory Demo Mode** with pre-seeded products, users, and orders.*

### 3. Starting the Application

#### Option A: Unified Dev Server (Default for Cloud / AI Studio)
Runs the backend API and frontend Vite server together on port 3000:
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

#### Option B: Concurrent Separate Ports (Vite on 5173 & Express on 5000)
Runs Vite on port 5173 and Express on port 5000 concurrently:
```bash
npm run dev:concurrent
```
Or in two separate terminals:
```bash
# Terminal 1: Backend Express Server (Port 5000)
npm run server

# Terminal 2: Frontend Vite Client (Port 5173)
npm run client
```
Open [http://localhost:5173](http://localhost:5173) in your browser. The frontend automatically communicates with `http://localhost:5000` via the configured Vite proxy or `VITE_API_URL`.

---

## 🔑 Demo Credentials

Fast one-click demo login buttons are provided in the Sign In modal:

| Role | Email | Password | Privileges |
|---|---|---|---|
| **Administrator** | `admin@stylekart.com` | `admin123` | Full Admin Portal, Product CRUD, Status Updates, Revenue Analytics |
| **Customer** | `user@stylekart.com` | `user123` | Shopping, Bag, Checkout, Order History Tracking |

---

## 📡 REST API Documentation

### Authentication
- `POST /api/auth/register` - Create new customer account (`{ name, email, password }`)
- `POST /api/auth/login` - Authenticate user & receive JWT token (`{ email, password }`)
- `GET /api/auth/me` - Retrieve authenticated user profile (Bearer token required)

### Products
- `GET /api/products` - List all products (supports `?category=`, `?search=`, `?sort=`, `?minPrice=`, `?maxPrice=`)
- `GET /api/products/:id` - Fetch single product details
- `POST /api/products` - Add product to inventory (Admin only)
- `PUT /api/products/:id` - Update existing product (Admin only)
- `DELETE /api/products/:id` - Remove product from inventory (Admin only)

### Orders
- `POST /api/orders` - Place new customer order (Customer token required)
- `GET /api/orders/my-orders` - List current customer's order history
- `GET /api/admin/orders` - List all customer orders across store (Admin only)
- `PUT /api/admin/orders/:id/status` - Update order status (`Pending`, `Processing`, `Shipped`, `Delivered`, `Cancelled`)
- `GET /api/admin/stats` - Summary of total sales, total orders, AOV, and pending orders

### System Diagnostics
- `GET /api/health` - Check database mode (`mongodb-atlas` or `in-memory-demo`) and server timestamp

---

## 🔒 Security & Payment Notice

- Passwords are encrypted with `bcryptjs` salt rounds.
- Payment flows (UPI, COD, Cards) are strictly simulated for sandbox evaluation; no financial credentials or cardholder data are processed or stored.
