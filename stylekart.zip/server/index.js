import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import mongoose from 'mongoose';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'stylekart_jwt_secret_dev_key_2026';
const MONGODB_URI = process.env.MONGODB_URI || '';

app.use(cors());
app.use(express.json());

// ----------------------------------------------------
// Initial Seed Data
// ----------------------------------------------------
const INITIAL_PRODUCTS = [
  {
    id: 'prod-1',
    name: 'Tailored Linen Unstructured Blazer',
    category: 'Fashion',
    price: 4999,
    originalPrice: 6999,
    rating: 4.8,
    reviewsCount: 124,
    stock: 28,
    image: '/src/assets/images/product_tailored_blazer_1792683257504.jpg',
    description: 'Masterfully cut in lightweight navy Italian linen. Unlined natural drape, horn buttons, patch pockets, and breathable all-season comfort.'
  },
  {
    id: 'prod-2',
    name: 'Studio Pro Active Noise-Cancelling Headphones',
    category: 'Electronics',
    price: 8499,
    originalPrice: 11999,
    rating: 4.9,
    reviewsCount: 218,
    stock: 45,
    image: '/src/assets/images/product_overear_headphones_1792683257767.jpg',
    description: 'Precision 40mm beryllium drivers, 38-hour battery longevity, hybrid active noise cancellation, and ultra-plush protein leather ear cups.'
  },
  {
    id: 'prod-3',
    name: 'Minimalist Heritage Chronograph Watch',
    category: 'Accessories',
    price: 6299,
    originalPrice: 8999,
    rating: 4.7,
    reviewsCount: 89,
    stock: 19,
    image: '/src/assets/images/product_leather_chronograph_1792683259138.jpg',
    description: 'Hand-stitched Tuscan leather strap, anti-reflective sapphire crystal glass, 316L surgical stainless steel casing, and Japanese quartz movement.'
  },
  {
    id: 'prod-4',
    name: 'Artisanal Cognac Leather Crossbody Saddle Bag',
    category: 'Accessories',
    price: 3899,
    originalPrice: 5499,
    rating: 4.8,
    reviewsCount: 76,
    stock: 14,
    image: '/src/assets/images/product_leather_crossbody_1792683259567.jpg',
    description: 'Full-grain vegetable-tanned saddle leather with antiqued solid brass hardware, magnetic snap flap closure, and dedicated phone sleeve.'
  },
  {
    id: 'prod-5',
    name: 'Pure Mongolian Cashmere Crewneck Sweater',
    category: 'Fashion',
    price: 3499,
    originalPrice: 4999,
    rating: 4.6,
    reviewsCount: 62,
    stock: 35,
    image: '/src/assets/images/hero_shopping_banner_1792683257533.jpg',
    description: 'Spun from two-ply Grade-A cashmere fibers. Ribbed hem and cuffs with a tailored, comfortable everyday silhouette.'
  },
  {
    id: 'prod-6',
    name: '13.5oz Raw Selvedge Japanese Denim Trousers',
    category: 'Fashion',
    price: 2799,
    originalPrice: 3999,
    rating: 4.7,
    reviewsCount: 94,
    stock: 22,
    image: '/src/assets/images/product_tailored_blazer_1792683257504.jpg',
    description: 'Shuttle-loom woven with classic red selvedge ID line, vintage copper rivets, button fly, and structured slim-tapered fit.'
  },
  {
    id: 'prod-7',
    name: 'Acoustic Mesh Portable Wireless Speaker',
    category: 'Electronics',
    price: 2499,
    originalPrice: 3499,
    rating: 4.5,
    reviewsCount: 112,
    stock: 50,
    image: '/src/assets/images/product_overear_headphones_1792683257767.jpg',
    description: 'Room-filling 360-degree spatial audio, IPX7 waterproof rating, Bluetooth 5.3, and up to 18 hours of continuous play.'
  },
  {
    id: 'prod-8',
    name: 'Hand-Poured Soy Wax Amber Scented Candle',
    category: 'Home',
    price: 899,
    originalPrice: 1299,
    rating: 4.9,
    reviewsCount: 153,
    stock: 60,
    image: '/src/assets/images/hero_shopping_banner_1792683257533.jpg',
    description: 'Infused with notes of cedarwood, smoked amber, and wild bergamot. Lead-free organic cotton wick with 55-hour clean burn.'
  }
];

// Pre-hashed passwords for 'admin123' and 'user123'
const HASHED_ADMIN_PASS = bcrypt.hashSync('admin123', 10);
const HASHED_USER_PASS = bcrypt.hashSync('user123', 10);

const INITIAL_USERS = [
  {
    id: 'user-admin',
    name: 'Priya Mehta (Admin)',
    email: 'admin@stylekart.com',
    password: HASHED_ADMIN_PASS,
    role: 'admin',
    createdAt: new Date().toISOString()
  },
  {
    id: 'user-cust-1',
    name: 'Aarav Sharma',
    email: 'user@stylekart.com',
    password: HASHED_USER_PASS,
    role: 'customer',
    createdAt: new Date().toISOString()
  }
];

const INITIAL_ORDERS = [
  {
    id: 'ORD-882194',
    userId: 'user-cust-1',
    customerName: 'Aarav Sharma',
    customerEmail: 'user@stylekart.com',
    customerPhone: '+91 98765 43210',
    shippingAddress: {
      address: 'Flat 402, Skyline Residency, Bandra West',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400050'
    },
    items: [
      {
        id: 'prod-1',
        name: 'Tailored Linen Unstructured Blazer',
        price: 4999,
        quantity: 1,
        image: '/src/assets/images/product_tailored_blazer_1792683257504.jpg'
      },
      {
        id: 'prod-3',
        name: 'Minimalist Heritage Chronograph Watch',
        price: 6299,
        quantity: 1,
        image: '/src/assets/images/product_leather_chronograph_1792683259138.jpg'
      }
    ],
    subtotal: 11298,
    discount: 500,
    shippingFee: 0,
    total: 10798,
    paymentMethod: 'Simulated UPI',
    status: 'Delivered',
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString()
  },
  {
    id: 'ORD-941823',
    userId: 'user-cust-1',
    customerName: 'Aarav Sharma',
    customerEmail: 'user@stylekart.com',
    customerPhone: '+91 98765 43210',
    shippingAddress: {
      address: 'Flat 402, Skyline Residency, Bandra West',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400050'
    },
    items: [
      {
        id: 'prod-2',
        name: 'Studio Pro Active Noise-Cancelling Headphones',
        price: 8499,
        quantity: 1,
        image: '/src/assets/images/product_overear_headphones_1792683257767.jpg'
      }
    ],
    subtotal: 8499,
    discount: 0,
    shippingFee: 0,
    total: 8499,
    paymentMethod: 'Cash on Delivery (Simulated)',
    status: 'Processing',
    createdAt: new Date(Date.now() - 86400000).toISOString()
  }
];

// ----------------------------------------------------
// Storage State (In-Memory fallback with Mongoose sync)
// ----------------------------------------------------
let isMongoConnected = false;

let memoryProducts = JSON.parse(JSON.stringify(INITIAL_PRODUCTS));
let memoryUsers = JSON.parse(JSON.stringify(INITIAL_USERS));
let memoryOrders = JSON.parse(JSON.stringify(INITIAL_ORDERS));

// Mongoose Schemas
const productSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  name: { type: String, required: true },
  category: { type: String, required: true },
  price: { type: Number, required: true },
  originalPrice: Number,
  rating: { type: Number, default: 4.5 },
  reviewsCount: { type: Number, default: 10 },
  stock: { type: Number, default: 20 },
  image: String,
  description: String
});

const userSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ['customer', 'admin'], default: 'customer' },
  createdAt: { type: String, default: () => new Date().toISOString() }
});

const orderSchema = new mongoose.Schema({
  id: { type: String, unique: true },
  userId: String,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
  shippingAddress: Object,
  items: Array,
  subtotal: Number,
  discount: Number,
  shippingFee: Number,
  total: Number,
  paymentMethod: String,
  status: { type: String, default: 'Processing' },
  createdAt: { type: String, default: () => new Date().toISOString() }
});

const MongoProduct = mongoose.models.Product || mongoose.model('Product', productSchema);
const MongoUser = mongoose.models.User || mongoose.model('User', userSchema);
const MongoOrder = mongoose.models.Order || mongoose.model('Order', orderSchema);

// Connect to MongoDB if URI is supplied
if (MONGODB_URI) {
  mongoose
    .connect(MONGODB_URI, { serverSelectionTimeoutMS: 3000 })
    .then(async () => {
      isMongoConnected = true;
      console.log('✅ Connected to MongoDB Atlas successfully.');
      // Seed if collections are empty
      const prodCount = await MongoProduct.countDocuments();
      if (prodCount === 0) {
        await MongoProduct.insertMany(INITIAL_PRODUCTS);
        console.log('Seeded initial products in MongoDB.');
      }
      const userCount = await MongoUser.countDocuments();
      if (userCount === 0) {
        await MongoUser.insertMany(INITIAL_USERS);
        console.log('Seeded initial users in MongoDB.');
      }
      const orderCount = await MongoOrder.countDocuments();
      if (orderCount === 0) {
        await MongoOrder.insertMany(INITIAL_ORDERS);
        console.log('Seeded initial orders in MongoDB.');
      }
    })
    .catch((err) => {
      isMongoConnected = false;
      console.warn('⚠️ MongoDB connection could not be established. Running in high-performance In-Memory Demo Mode.');
      console.warn('Reason:', err.message);
    });
} else {
  console.log('ℹ️ No MONGODB_URI provided. Running StyleKart in high-fidelity In-Memory Demo Mode.');
}

// ----------------------------------------------------
// Authentication Helpers & Middleware
// ----------------------------------------------------
function generateToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, name: user.name, role: user.role },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Access token required' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }
}

function adminMiddleware(req, res, next) {
  authMiddleware(req, res, () => {
    if (req.user && req.user.role === 'admin') {
      next();
    } else {
      res.status(403).json({ error: 'Admin privileges required' });
    }
  });
}

// ----------------------------------------------------
// Routes: System Health & Info
// ----------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    storeName: 'StyleKart',
    databaseMode: isMongoConnected ? 'mongodb-atlas' : 'in-memory-demo',
    mongoConnected: isMongoConnected,
    productCount: memoryProducts.length,
    orderCount: memoryOrders.length,
    timestamp: new Date().toISOString()
  });
});

// ----------------------------------------------------
// Routes: Auth
// ----------------------------------------------------
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    const normalizedEmail = email.trim().toLowerCase();

    // Check duplicate
    if (isMongoConnected) {
      const existing = await MongoUser.findOne({ email: normalizedEmail });
      if (existing) {
        return res.status(400).json({ error: 'An account with this email already exists' });
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = new MongoUser({
        id: `user-${Date.now()}`,
        name: name.trim(),
        email: normalizedEmail,
        password: hashedPassword,
        role: 'customer'
      });
      await newUser.save();
      const token = generateToken(newUser);
      return res.status(201).json({
        message: 'Account created successfully',
        token,
        user: { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role }
      });
    } else {
      const existing = memoryUsers.find((u) => u.email === normalizedEmail);
      if (existing) {
        return res.status(400).json({ error: 'An account with this email already exists' });
      }
      const hashedPassword = await bcrypt.hash(password, 10);
      const newUser = {
        id: `user-${Date.now()}`,
        name: name.trim(),
        email: normalizedEmail,
        password: hashedPassword,
        role: 'customer',
        createdAt: new Date().toISOString()
      };
      memoryUsers.push(newUser);
      const token = generateToken(newUser);
      return res.status(201).json({
        message: 'Account created successfully',
        token,
        user: { id: newUser.id, name: newUser.name, email: newUser.email, role: newUser.role }
      });
    }
  } catch (err) {
    res.status(500).json({ error: err.message || 'Registration failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }

    const normalizedEmail = email.trim().toLowerCase();

    let user = null;
    if (isMongoConnected) {
      user = await MongoUser.findOne({ email: normalizedEmail });
    } else {
      user = memoryUsers.find((u) => u.email === normalizedEmail);
    }

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = generateToken(user);
    res.json({
      message: 'Login successful',
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Login failed' });
  }
});

app.get('/api/auth/me', authMiddleware, async (req, res) => {
  try {
    let user = null;
    if (isMongoConnected) {
      user = await MongoUser.findOne({ id: req.user.id });
    } else {
      user = memoryUsers.find((u) => u.id === req.user.id);
    }

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve profile' });
  }
});

// ----------------------------------------------------
// Routes: Products
// ----------------------------------------------------
app.get('/api/products', async (req, res) => {
  try {
    let items = [];
    if (isMongoConnected) {
      items = await MongoProduct.find();
    } else {
      items = [...memoryProducts];
    }

    const { category, search, sort, minPrice, maxPrice } = req.query;

    if (category && category !== 'All') {
      items = items.filter((p) => p.category.toLowerCase() === category.toLowerCase());
    }

    if (search) {
      const q = search.toLowerCase();
      items = items.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    }

    if (minPrice) {
      const min = parseFloat(minPrice);
      if (!isNaN(min)) items = items.filter((p) => p.price >= min);
    }

    if (maxPrice) {
      const max = parseFloat(maxPrice);
      if (!isNaN(max)) items = items.filter((p) => p.price <= max);
    }

    if (sort) {
      if (sort === 'price-asc') items.sort((a, b) => a.price - b.price);
      else if (sort === 'price-desc') items.sort((a, b) => b.price - a.price);
      else if (sort === 'rating') items.sort((a, b) => b.rating - a.rating);
      else if (sort === 'name') items.sort((a, b) => a.name.localeCompare(b.name));
    }

    res.json({ products: items, total: items.length });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

app.get('/api/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    let product = null;
    if (isMongoConnected) {
      product = await MongoProduct.findOne({ id });
    } else {
      product = memoryProducts.find((p) => p.id === id);
    }

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ product });
  } catch (err) {
    res.status(500).json({ error: 'Failed to retrieve product' });
  }
});

// Admin: Add Product
app.post('/api/products', adminMiddleware, async (req, res) => {
  try {
    const { name, category, price, originalPrice, stock, image, description } = req.body;
    if (!name || !category || price === undefined) {
      return res.status(400).json({ error: 'Name, category and price are required' });
    }

    const newProd = {
      id: `prod-${Date.now()}`,
      name: name.trim(),
      category: category.trim(),
      price: Number(price),
      originalPrice: originalPrice ? Number(originalPrice) : Number(price) * 1.25,
      rating: 4.8,
      reviewsCount: 1,
      stock: stock !== undefined ? Number(stock) : 25,
      image: image || '/src/assets/images/product_tailored_blazer_1792683257504.jpg',
      description: description || 'High quality crafted merchandise from StyleKart.'
    };

    if (isMongoConnected) {
      const doc = new MongoProduct(newProd);
      await doc.save();
    }
    memoryProducts.unshift(newProd);

    res.status(201).json({ message: 'Product added successfully', product: newProd });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create product' });
  }
});

// Admin: Update Product
app.put('/api/products/:id', adminMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { name, category, price, originalPrice, stock, image, description } = req.body;

    let updated = null;
    if (isMongoConnected) {
      updated = await MongoProduct.findOneAndUpdate(
        { id },
        { name, category, price, originalPrice, stock, image, description },
        { new: true }
      );
    }

    const idx = memoryProducts.findIndex((p) => p.id === id);
    if (idx !== -1) {
      memoryProducts[idx] = {
        ...memoryProducts[idx],
        ...(name && { name }),
        ...(category && { category }),
        ...(price !== undefined && { price: Number(price) }),
        ...(originalPrice !== undefined && { originalPrice: Number(originalPrice) }),
        ...(stock !== undefined && { stock: Number(stock) }),
        ...(image && { image }),
        ...(description && { description })
      };
      updated = memoryProducts[idx];
    }

    if (!updated) {
      return res.status(404).json({ error: 'Product not found' });
    }

    res.json({ message: 'Product updated successfully', product: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update product' });
  }
});

// Admin: Delete Product
app.delete('/api/products/:id', adminMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    if (isMongoConnected) {
      await MongoProduct.findOneAndDelete({ id });
    }
    memoryProducts = memoryProducts.filter((p) => p.id !== id);
    res.json({ message: 'Product removed successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete product' });
  }
});

// ----------------------------------------------------
// Routes: Customer Orders & Checkout
// ----------------------------------------------------
app.post('/api/orders', authMiddleware, async (req, res) => {
  try {
    const { items, shippingAddress, customerName, customerPhone, paymentMethod } = req.body;

    if (!items || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Cart items are required' });
    }

    if (!shippingAddress || !shippingAddress.address || !shippingAddress.city || !shippingAddress.pincode) {
      return res.status(400).json({ error: 'Complete shipping address is required' });
    }

    // Calculate subtotal and verify stock
    let subtotal = 0;
    const orderItems = [];

    for (const item of items) {
      let product = null;
      if (isMongoConnected) {
        product = await MongoProduct.findOne({ id: item.id });
      } else {
        product = memoryProducts.find((p) => p.id === item.id);
      }

      if (!product) {
        return res.status(400).json({ error: `Product ${item.name || item.id} no longer exists.` });
      }

      if (product.stock < item.quantity) {
        return res.status(400).json({
          error: `Insufficient stock for "${product.name}". Only ${product.stock} available.`
        });
      }

      // Decrement stock
      const newStock = Math.max(0, product.stock - item.quantity);
      if (isMongoConnected) {
        await MongoProduct.findOneAndUpdate({ id: product.id }, { stock: newStock });
      }
      product.stock = newStock;

      const lineTotal = product.price * item.quantity;
      subtotal += lineTotal;

      orderItems.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: item.quantity,
        image: product.image
      });
    }

    const shippingFee = subtotal >= 999 ? 0 : 99;
    const discount = req.body.discount || 0;
    const total = Math.max(0, subtotal - discount + shippingFee);

    const newOrder = {
      id: `ORD-${Math.floor(100000 + Math.random() * 900000)}`,
      userId: req.user.id,
      customerName: customerName || req.user.name,
      customerEmail: req.user.email,
      customerPhone: customerPhone || '+91 98765 00000',
      shippingAddress,
      items: orderItems,
      subtotal,
      discount,
      shippingFee,
      total,
      paymentMethod: paymentMethod || 'Simulated UPI',
      status: 'Processing',
      createdAt: new Date().toISOString()
    };

    if (isMongoConnected) {
      const doc = new MongoOrder(newOrder);
      await doc.save();
    }
    memoryOrders.unshift(newOrder);

    res.status(201).json({
      message: 'Order placed successfully! Delivery simulation scheduled.',
      order: newOrder
    });
  } catch (err) {
    res.status(500).json({ error: err.message || 'Checkout failed' });
  }
});

// Customer: My Orders
app.get('/api/orders/my-orders', authMiddleware, async (req, res) => {
  try {
    let orders = [];
    if (isMongoConnected) {
      orders = await MongoOrder.find({ userId: req.user.id }).sort({ createdAt: -1 });
    } else {
      orders = memoryOrders.filter((o) => o.userId === req.user.id);
    }
    res.json({ orders });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch customer orders' });
  }
});

// ----------------------------------------------------
// Routes: Admin Portal
// ----------------------------------------------------
app.get('/api/admin/orders', adminMiddleware, async (req, res) => {
  try {
    let orders = [];
    if (isMongoConnected) {
      orders = await MongoOrder.find().sort({ createdAt: -1 });
    } else {
      orders = [...memoryOrders];
    }
    res.json({ orders, total: orders.length });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch admin orders' });
  }
});

app.put('/api/admin/orders/:id/status', adminMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const allowed = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
    if (!allowed.includes(status)) {
      return res.status(400).json({ error: 'Invalid order status value' });
    }

    let updated = null;
    if (isMongoConnected) {
      updated = await MongoOrder.findOneAndUpdate({ id }, { status }, { new: true });
    }

    const order = memoryOrders.find((o) => o.id === id);
    if (order) {
      order.status = status;
      updated = order;
    }

    if (!updated) {
      return res.status(404).json({ error: 'Order not found' });
    }

    res.json({ message: 'Order status updated', order: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update order status' });
  }
});

app.get('/api/admin/stats', adminMiddleware, async (req, res) => {
  try {
    let orders = isMongoConnected ? await MongoOrder.find() : memoryOrders;
    let products = isMongoConnected ? await MongoProduct.find() : memoryProducts;
    let users = isMongoConnected ? await MongoUser.find() : memoryUsers;

    const totalSales = orders.reduce((acc, curr) => acc + (curr.total || 0), 0);
    const totalOrders = orders.length;
    const avgOrderValue = totalOrders > 0 ? Math.round(totalSales / totalOrders) : 0;
    const pendingOrders = orders.filter((o) => o.status === 'Processing' || o.status === 'Pending').length;
    const lowStockProducts = products.filter((p) => p.stock < 15).length;

    res.json({
      totalSales,
      totalOrders,
      avgOrderValue,
      pendingOrders,
      totalProducts: products.length,
      totalUsers: users.length,
      lowStockProducts,
      databaseMode: isMongoConnected ? 'MongoDB Atlas' : 'In-Memory Demo Mode'
    });
  } catch (err) {
    res.status(500).json({ error: 'Failed to calculate stats' });
  }
});

// Central 404 handler for unknown API routes
app.all('/api/*', (req, res) => {
  res.status(404).json({ error: `API route ${req.method} ${req.originalUrl} not found` });
});

// Export app for server.ts integration
export default app;

// If started directly in standalone mode
if (process.env.NODE_ENV !== 'test' && !process.env.RUNNING_IN_VITE) {
  // Only start listening if this file is the main module
  const isDirectRun = process.argv[1]?.includes('server/index.js');
  if (isDirectRun) {
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 StyleKart Backend Server running on http://localhost:${PORT}`);
    });
  }
}
